import React from 'react';
import TabsGrid from '../Common/TabsGrid';
import Head from 'next/head';
const Home = () => {

    return (
        <div>
           
            <TabsGrid></TabsGrid>
        </div>
    );
};

export default Home;