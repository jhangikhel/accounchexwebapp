// @flow 
import * as React from 'react';
type Props = {
    
};
export const Workbasket = (props: Props) => {
    return (
        <div>
            WorkBaset
        </div>
    );
};