import React from 'react';
import CenteredTabs from '../Common/Tabs';
import Head from 'next/head';
const Home = () => {

    return (
        <div>
           
            <CenteredTabs></CenteredTabs>
        </div>
    );
};

export default Home;