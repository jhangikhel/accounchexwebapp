// @flow 
import * as React from 'react';
type Props = {
    
};
export const Search = (props: Props) => {
    return (
        <div>
            Search
        </div>
    );
};