// @flow 
import * as React from 'react';
type Props = {
    
};
export const WorkBaset = (props: Props) => {
    return (
        <div>
            WorkBaset
        </div>
    );
};