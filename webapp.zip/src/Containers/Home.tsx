import React from 'react';

const Home = () => {
    alert("HOme");
    return (
        <div>
            Test
        </div>
    );
};

export default Home;