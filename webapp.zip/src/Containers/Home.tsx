import React from 'react';
import CenteredTabs from './../Common/Tabs';

const Home = () => {
    alert("HOme");
    return (
        <div>
            <CenteredTabs></CenteredTabs>
        </div>
    );
};

export default Home;