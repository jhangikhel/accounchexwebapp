import React from 'react';
import './App.css';

const App: React.FC = () => {
  return <div>Test</div>
}

export default App;
