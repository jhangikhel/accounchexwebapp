import Header from './Common/Header';
import './App.css';
import './Content/CSS/style.css';
import CustomTheme from './Common/CustomTheme';
import { Route, Routes } from 'react-router-dom';
import Home from './Containers/Home';
import Master from './Common/Master';
import { Search } from './Containers/Search';
import { WorkBaset } from './Containers/WorkBaset';

function App() {
  return (

    <Routes>

      <Route path='/' element={<Master><Home /></Master>}>
      </Route>
      <Route path='/Search' element={<Master><Search /></Master>}>
      </Route>
      <Route path='/Workbasket' element={<Master><WorkBaset /></Master>}>
      </Route>
    </Routes>




  );
}

export default App;
