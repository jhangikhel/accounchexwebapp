import Header from './Common/Header';
import './App.css';

import CustomTheme from './Common/CustomTheme';
import { Route, Routes } from 'react-router-dom';
import Home from './Containers/Home';
import Master from './Common/Master';
import { Search } from './Containers/Search';


function App() {
  return (
    <>
    </>);
}

export default App;
